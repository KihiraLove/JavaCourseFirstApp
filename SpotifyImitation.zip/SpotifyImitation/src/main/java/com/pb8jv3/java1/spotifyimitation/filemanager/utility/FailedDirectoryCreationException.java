package com.pb8jv3.java1.spotifyimitation.filemanager.utility;

/**
 *
 * @author Kertesz Domonkos PB8JV3
 */
public class FailedDirectoryCreationException extends Exception{

    public FailedDirectoryCreationException(String string) {
	super(string);
    }
}
